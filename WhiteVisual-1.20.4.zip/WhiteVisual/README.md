# White Visual (Fabric 1.20.4)

Client-side visual mod, 36 modules. Open ClickGUI with **Right Shift**.

## Build
Requirements: JDK 17+, internet (Gradle downloads Minecraft/Fabric).

* IntelliJ IDEA: File > Open > select this folder > wait for Gradle sync > Gradle panel > Tasks > build > build.
* Or CLI (if Gradle 8.5+ is installed): `gradle build`  (or `gradle wrapper --gradle-version 8.5` once, then `./gradlew build`).

Result: `build/libs/white-visual-1.0.0.jar` (use this one, not the -sources jar).
Put it in `.minecraft/mods` together with Fabric Loader 0.15+ and Fabric API for 1.20.4.

## ClickGUI
LMB toggles a module, RMB opens its settings, hover a module + press a key = bind (Del clears).
Config: `.minecraft/config/whitevisual.properties`.

## Modules
Render: TargetESP (Ring/Pulse/Orbit), ChinaHat, PlayerESP, MobESP, ItemESP, Tracers, Trails, Hitboxes, Halo, JumpCircles, FeetCircle, Glow
HUD: Watermark, ArrayList, TargetHUD, ArmorHUD, Potions, XYZ, FPS, Ping, BPS, Clock, Facing, Server, Totems, CPS, Players, Memory, Durability, Combo, Health
Misc: Theme, FullBright, Zoom, FovChanger, HitParticles
