package white.visual.modules;

import net.minecraft.client.render.Camera;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import white.visual.core.Category;
import white.visual.core.Mod;
import white.visual.core.RenderUtil;
import white.visual.core.Setting;
import white.visual.core.Target;
import white.visual.core.Theme;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public final class RenderMods {
    private RenderMods() {}

    // ------------------------------------------------------------ TargetESP
    public static class TargetESP extends Mod {
        final Setting mode = add(Setting.mode("Mode", new String[]{"Ring", "Pulse", "Orbit"}, 0));
        final Setting color = add(Setting.mode("Color", Theme.MODES, 1));
        final Setting duration = add(Setting.num("Duration", 6, 1, 20, 1));
        final Setting flash = add(Setting.bool("Hurt Flash", true));

        public TargetESP() { super("TargetESP", Category.RENDER); }

        @Override
        public void onRender3d(MatrixStack ms, float td) {
            LivingEntity t = Target.get((long) (duration.d() * 1000));
            if (t == null) return;
            Vec3d p = RenderUtil.pos(t, td);
            double w = t.getWidth(), h = t.getHeight();
            double time = System.currentTimeMillis() / 1000.0;
            int c = (flash.b() && t.hurtTime > 0) ? 4 : color.i();

            RenderUtil.begin(false);
            switch (mode.i()) {
                case 0 -> {
                    double s = Math.sin(time * 2.4);
                    double y = p.y + (s * 0.5 + 0.5) * h;
                    double dir = Math.cos(time * 2.4) > 0 ? 1 : -1;
                    double r = w * 0.85 + 0.1;
                    RenderUtil.ribbon(ms, p.x, p.z, r, y, 200, r, y - dir * 0.4, 0, c, 0, 48);
                    RenderUtil.ringLine(ms, p.x, y, p.z, r, c, 255, 48, 2.5f);
                }
                case 1 -> {
                    for (int k = 0; k < 2; k++) {
                        double ph = (time * 0.9 + k * 0.5) % 1;
                        double r = w * 0.5 + ph * 1.1;
                        int a = (int) (220 * (1 - ph));
                        RenderUtil.ribbon(ms, p.x, p.z, r - 0.12, p.y + 0.02, a, r, p.y + 0.02, a, c, 0, 48);
                        RenderUtil.ringLine(ms, p.x, p.y + 0.02, p.z, r, c, a, 48, 2f);
                    }
                }
                default -> {
                    for (int k = 0; k < 3; k++) {
                        double ang = time * 3 + k * Math.PI * 2 / 3;
                        double r = w * 0.9 + 0.2;
                        double cx = p.x + Math.cos(ang) * r, cz = p.z + Math.sin(ang) * r;
                        double cy = p.y + h * 0.5 + Math.sin(time * 2 + k * 2) * h * 0.3;
                        RenderUtil.box(ms, new Box(cx - .07, cy - .07, cz - .07, cx + .07, cy + .07, cz + .07),
                                Theme.rgb(c, k * 0.33), 200, 255);
                    }
                }
            }
            RenderUtil.end();
        }
    }

    // ------------------------------------------------------------ ChinaHat
    public static class ChinaHat extends Mod {
        final Setting color = add(Setting.mode("Color", Theme.MODES, 1));
        final Setting alpha = add(Setting.num("Alpha", 120, 30, 255, 5));
        final Setting radius = add(Setting.num("Radius", 0.6, 0.3, 1.0, 0.05));
        final Setting height = add(Setting.num("Height", 0.3, 0.1, 0.7, 0.05));
        final Setting outline = add(Setting.bool("Outline", true));
        final Setting others = add(Setting.bool("Others", false));

        public ChinaHat() { super("ChinaHat", Category.RENDER); }

        @Override
        public void onRender3d(MatrixStack ms, float td) {
            boolean first = mc.options.getPerspective().isFirstPerson();
            RenderUtil.begin(true);
            for (PlayerEntity e : mc.world.getPlayers()) {
                if (e == mc.player) { if (first) continue; }
                else if (!others.b()) continue;
                Vec3d p = RenderUtil.pos(e, td);
                double y = p.y + e.getHeight() - 0.05;
                RenderUtil.ribbon(ms, p.x, p.z, radius.d(), y, alpha.i(), 0, y + height.d(), alpha.i(),
                        color.i(), 0, 48);
                if (outline.b()) RenderUtil.ringLine(ms, p.x, y, p.z, radius.d(), color.i(), 255, 48, 2f);
            }
            RenderUtil.end();
        }
    }

    // ------------------------------------------------------------ PlayerESP
    public static class PlayerESP extends Mod {
        final Setting color = add(Setting.mode("Color", Theme.MODES, 0));
        final Setting fill = add(Setting.num("Fill", 40, 0, 120, 5));

        public PlayerESP() { super("PlayerESP", Category.RENDER); }

        @Override
        public void onRender3d(MatrixStack ms, float td) {
            RenderUtil.begin(false);
            for (PlayerEntity p : mc.world.getPlayers()) {
                if (p == mc.player) continue;
                RenderUtil.box(ms, RenderUtil.entityBox(p, td), Theme.rgb(color.i(), 0), fill.i(), 255);
            }
            RenderUtil.end();
        }
    }

    // ------------------------------------------------------------ MobESP
    public static class MobESP extends Mod {
        final Setting color = add(Setting.mode("Color", Theme.MODES, 4));
        final Setting passive = add(Setting.bool("Passive", true));
        final Setting fill = add(Setting.num("Fill", 30, 0, 120, 5));

        public MobESP() { super("MobESP", Category.RENDER); }

        @Override
        public void onRender3d(MatrixStack ms, float td) {
            RenderUtil.begin(false);
            for (Entity e : mc.world.getEntities()) {
                if (!(e instanceof MobEntity) || !e.isAlive()) continue;
                boolean hostile = e instanceof HostileEntity;
                if (!hostile && !passive.b()) continue;
                int rgb = hostile ? Theme.rgb(color.i(), 0) : 0x66FF88;
                RenderUtil.box(ms, RenderUtil.entityBox(e, td), rgb, fill.i(), 255);
            }
            RenderUtil.end();
        }
    }

    // ------------------------------------------------------------ ItemESP
    public static class ItemESP extends Mod {
        final Setting color = add(Setting.mode("Color", Theme.MODES, 2));

        public ItemESP() { super("ItemESP", Category.RENDER); }

        @Override
        public void onRender3d(MatrixStack ms, float td) {
            RenderUtil.begin(false);
            for (Entity e : mc.world.getEntities()) {
                if (e instanceof ItemEntity)
                    RenderUtil.box(ms, RenderUtil.entityBox(e, td), Theme.rgb(color.i(), 0), 50, 255);
            }
            RenderUtil.end();
        }
    }

    // ------------------------------------------------------------ Tracers
    public static class Tracers extends Mod {
        final Setting color = add(Setting.mode("Color", Theme.MODES, 1));
        final Setting mobs = add(Setting.bool("Mobs", false));

        public Tracers() { super("Tracers", Category.RENDER); }

        @Override
        public void onRender3d(MatrixStack ms, float td) {
            Camera cam = mc.gameRenderer.getCamera();
            Vec3d start = cam.getPos().add(Vec3d.fromPolar(cam.getPitch(), cam.getYaw()));
            RenderUtil.begin(false);
            for (Entity e : mc.world.getEntities()) {
                boolean ok = (e instanceof PlayerEntity && e != mc.player)
                        || (mobs.b() && e instanceof HostileEntity && e.isAlive());
                if (!ok) continue;
                Vec3d p = RenderUtil.pos(e, td).add(0, e.getHeight() / 2, 0);
                RenderUtil.line(ms, start, p, Theme.rgb(color.i(), 0), Theme.rgb(color.i(), 0.5), 220, 2f);
            }
            RenderUtil.end();
        }
    }

    // ------------------------------------------------------------ Trails
    public static class Trails extends Mod {
        final Setting color = add(Setting.mode("Color", Theme.MODES, 1));
        final Setting length = add(Setting.num("Length", 40, 10, 120, 5));
        private final List<Vec3d> pts = new ArrayList<>();

        public Trails() { super("Trails", Category.RENDER); }

        @Override public void onDisable() { pts.clear(); }

        @Override
        public void onTick() {
            if (mc.player == null) return;
            pts.add(0, mc.player.getPos().add(0, 0.05, 0));
            while (pts.size() > length.i()) pts.remove(pts.size() - 1);
        }

        @Override
        public void onRender3d(MatrixStack ms, float td) {
            if (pts.size() < 2) return;
            RenderUtil.begin(true);
            for (int i = 0; i < pts.size() - 1; i++) {
                int a = (int) (255 * (1.0 - (double) i / pts.size()));
                RenderUtil.line(ms, pts.get(i), pts.get(i + 1),
                        Theme.rgb(color.i(), i * 0.02), Theme.rgb(color.i(), (i + 1) * 0.02), a, 3f);
            }
            RenderUtil.end();
        }
    }

    // ------------------------------------------------------------ Hitboxes
    public static class Hitboxes extends Mod {
        public Hitboxes() { super("Hitboxes", Category.RENDER); }

        @Override public void onTick() { mc.getEntityRenderDispatcher().setRenderHitboxes(true); }
        @Override public void onDisable() { mc.getEntityRenderDispatcher().setRenderHitboxes(false); }
    }

    // ------------------------------------------------------------ Halo
    public static class Halo extends Mod {
        final Setting color = add(Setting.mode("Color", Theme.MODES, 1));
        final Setting others = add(Setting.bool("Others", false));

        public Halo() { super("Halo", Category.RENDER); }

        @Override
        public void onRender3d(MatrixStack ms, float td) {
            boolean first = mc.options.getPerspective().isFirstPerson();
            double time = System.currentTimeMillis() / 1000.0;
            RenderUtil.begin(true);
            for (PlayerEntity e : mc.world.getPlayers()) {
                if (e == mc.player) { if (first) continue; }
                else if (!others.b()) continue;
                Vec3d p = RenderUtil.pos(e, td);
                double y = p.y + e.getHeight() + 0.25 + Math.sin(time * 2) * 0.03;
                RenderUtil.ribbon(ms, p.x, p.z, 0.28, y, 230, 0.36, y, 230, color.i(), 0, 36);
                RenderUtil.ringLine(ms, p.x, y, p.z, 0.36, color.i(), 255, 36, 2f);
            }
            RenderUtil.end();
        }
    }

    // ------------------------------------------------------------ JumpCircles
    public static class JumpCircles extends Mod {
        final Setting color = add(Setting.mode("Color", Theme.MODES, 1));
        private final List<double[]> rings = new ArrayList<>();
        private boolean wasGround;

        public JumpCircles() { super("JumpCircles", Category.RENDER); }

        @Override
        public void onTick() {
            if (mc.player == null) return;
            boolean g = mc.player.isOnGround();
            if (wasGround && !g && mc.player.getVelocity().y > 0.1)
                rings.add(new double[]{mc.player.getX(), mc.player.getY(), mc.player.getZ(), System.currentTimeMillis()});
            wasGround = g;
            long now = System.currentTimeMillis();
            Iterator<double[]> it = rings.iterator();
            while (it.hasNext()) if (now - it.next()[3] > 1200) it.remove();
        }

        @Override
        public void onRender3d(MatrixStack ms, float td) {
            if (rings.isEmpty()) return;
            long now = System.currentTimeMillis();
            RenderUtil.begin(true);
            for (double[] r : rings) {
                double p = (now - r[3]) / 1200.0;
                double rad = 0.3 + p * 1.8;
                int a = (int) (200 * (1 - p));
                RenderUtil.ribbon(ms, r[0], r[2], rad - 0.15, r[1] + 0.02, a, rad, r[1] + 0.02, a, color.i(), 0, 48);
                RenderUtil.ringLine(ms, r[0], r[1] + 0.02, r[2], rad, color.i(), a, 48, 2f);
            }
            RenderUtil.end();
        }
    }

    // ------------------------------------------------------------ FeetCircle
    public static class FeetCircle extends Mod {
        final Setting color = add(Setting.mode("Color", Theme.MODES, 2));
        final Setting fill = add(Setting.bool("Fill", true));

        public FeetCircle() { super("FeetCircle", Category.RENDER); }

        @Override
        public void onRender3d(MatrixStack ms, float td) {
            Vec3d p = RenderUtil.pos(mc.player, td);
            double time = System.currentTimeMillis() / 1000.0;
            double r = 0.75 + Math.sin(time * 2) * 0.08;
            RenderUtil.begin(true);
            if (fill.b()) RenderUtil.ribbon(ms, p.x, p.z, 0, p.y + 0.02, 40, r, p.y + 0.02, 40, color.i(), 0, 48);
            RenderUtil.ribbon(ms, p.x, p.z, r - 0.08, p.y + 0.02, 170, r, p.y + 0.02, 170, color.i(), 0, 48);
            RenderUtil.ringLine(ms, p.x, p.y + 0.02, p.z, r, color.i(), 255, 48, 2f);
            RenderUtil.end();
        }
    }

    // ------------------------------------------------------------ Glow
    public static class Glow extends Mod {
        public Glow() { super("Glow", Category.RENDER); }

        @Override
        public void onTick() {
            for (PlayerEntity p : mc.world.getPlayers()) if (p != mc.player) p.setGlowing(true);
        }

        @Override
        public void onDisable() {
            if (mc.world == null) return;
            for (PlayerEntity p : mc.world.getPlayers()) p.setGlowing(false);
        }
    }
}
