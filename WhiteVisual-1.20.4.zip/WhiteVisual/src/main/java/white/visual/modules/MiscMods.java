package white.visual.modules;

import net.minecraft.entity.Entity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.particle.ParticleTypes;
import white.visual.core.Category;
import white.visual.core.Mod;
import white.visual.core.Setting;
import white.visual.core.Theme;

public final class MiscMods {
    private MiscMods() {}

    // Global accent colour for HUD / ClickGUI
    public static class ThemeMod extends Mod {
        final Setting color = add(Setting.mode("Accent", Theme.MODES, 2));

        public ThemeMod() {
            super("Theme", Category.MISC);
            Theme.accent = color;
        }
    }

    public static class FullBright extends Mod {
        public FullBright() { super("FullBright", Category.MISC); }

        @Override
        public void onTick() {
            if (mc.player == null) return;
            StatusEffectInstance i = mc.player.getStatusEffect(StatusEffects.NIGHT_VISION);
            if (i == null || i.getDuration() < 400)
                mc.player.addStatusEffect(new StatusEffectInstance(StatusEffects.NIGHT_VISION, 1200, 0, false, false, false));
        }

        @Override
        public void onDisable() {
            if (mc.player != null) mc.player.removeStatusEffect(StatusEffects.NIGHT_VISION);
        }
    }

    public static class Zoom extends Mod {
        final Setting fov = add(Setting.num("FOV", 30, 30, 70, 1));
        private Integer old;

        public Zoom() { super("Zoom", Category.MISC); }

        @Override
        public void onTick() {
            var o = mc.options.getFov();
            if (old == null) old = o.getValue();
            int t = fov.i();
            if (o.getValue() != t) o.setValue(t);
        }

        @Override
        public void onDisable() {
            if (old != null) { mc.options.getFov().setValue(old); old = null; }
        }
    }

    public static class FovChanger extends Mod {
        final Setting fov = add(Setting.num("FOV", 100, 30, 110, 1));
        private Integer old;

        public FovChanger() { super("FovChanger", Category.MISC); }

        @Override
        public void onTick() {
            var o = mc.options.getFov();
            if (old == null) old = o.getValue();
            int t = fov.i();
            if (o.getValue() != t) o.setValue(t);
        }

        @Override
        public void onDisable() {
            if (old != null) { mc.options.getFov().setValue(old); old = null; }
        }
    }

    public static class HitParticles extends Mod {
        final Setting type = add(Setting.mode("Type", new String[]{"Crit", "Heart", "Flame", "End Rod", "Soul"}, 0));
        final Setting count = add(Setting.num("Count", 12, 1, 40, 1));

        public HitParticles() { super("HitParticles", Category.MISC); }

        @Override
        public void onAttack(Entity e) {
            if (mc.world == null) return;
            ParticleEffect[] t = {ParticleTypes.CRIT, ParticleTypes.HEART, ParticleTypes.FLAME,
                    ParticleTypes.END_ROD, ParticleTypes.SOUL_FIRE_FLAME};
            ParticleEffect p = t[type.i()];
            for (int i = 0; i < count.i(); i++) {
                double r = mc.world.random.nextDouble();
                mc.world.addParticle(p,
                        e.getX() + (mc.world.random.nextDouble() - 0.5) * e.getWidth() * 1.5,
                        e.getY() + r * e.getHeight(),
                        e.getZ() + (mc.world.random.nextDouble() - 0.5) * e.getWidth() * 1.5,
                        (mc.world.random.nextDouble() - 0.5) * 0.3, 0.1 + r * 0.2,
                        (mc.world.random.nextDouble() - 0.5) * 0.3);
            }
        }
    }
}
