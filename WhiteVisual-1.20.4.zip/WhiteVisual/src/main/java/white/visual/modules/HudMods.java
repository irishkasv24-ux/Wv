package white.visual.modules;

import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.math.MathHelper;
import org.lwjgl.glfw.GLFW;
import white.visual.core.Category;
import white.visual.core.Mod;
import white.visual.core.ModuleManager;
import white.visual.core.Setting;
import white.visual.core.Target;
import white.visual.core.Theme;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.function.Supplier;

public final class HudMods {
    private HudMods() {}

    static String f(String fmt, Object... a) { return String.format(Locale.ROOT, fmt, a); }

    // ------------------------------------------------------------ Watermark
    public static class Watermark extends Mod {
        final Setting color = add(Setting.mode("Color", Theme.MODES, 2));
        final Setting fps = add(Setting.bool("Show FPS", true));
        final Setting user = add(Setting.bool("Show Name", true));

        public Watermark() { super("Watermark", Category.HUD); }

        @Override
        public void onHud(DrawContext ctx, float td) {
            TextRenderer tr = mc.textRenderer;
            String a = "White", b = " Visual";
            String extra = (fps.b() ? " | " + mc.getCurrentFps() + " fps" : "")
                    + (user.b() ? " | " + mc.getSession().getUsername() : "");
            int w = tr.getWidth(a + b + extra) + 10;
            ctx.fill(4, 4, 4 + w, 17, 0xA0101010);
            for (int x = 0; x < w; x += 2)
                ctx.fill(4 + x, 4, 6 + x, 5, Theme.argb(Theme.rgb(color.i(), x / (double) w), 255));
            ctx.drawTextWithShadow(tr, a, 9, 7, 0xFFFFFFFF);
            ctx.drawTextWithShadow(tr, b, 9 + tr.getWidth(a), 7, Theme.argb(Theme.rgb(color.i(), 0.2), 255));
            ctx.drawTextWithShadow(tr, extra, 9 + tr.getWidth(a + b), 7, 0xFFAAAAAA);
        }
    }

    // ------------------------------------------------------------ ArrayList
    public static class ArrayListHud extends Mod {
        final Setting color = add(Setting.mode("Color", Theme.MODES, 2));

        public ArrayListHud() { super("ArrayList", Category.HUD); }

        @Override
        public void onHud(DrawContext ctx, float td) {
            TextRenderer tr = mc.textRenderer;
            List<Mod> l = new ArrayList<>();
            for (Mod m : ModuleManager.modules) if (m.enabled && m.category != Category.HUD) l.add(m);
            l.sort(Comparator.comparingInt((Mod m) -> -tr.getWidth(m.name)));
            int sw = mc.getWindow().getScaledWidth();
            int y = 4, i = 0;
            for (Mod m : l) {
                int w = tr.getWidth(m.name);
                int rgb = Theme.rgb(color.i(), i * 0.08);
                ctx.fill(sw - w - 8, y, sw - 2, y + 11, 0x90101010);
                ctx.fill(sw - 2, y, sw, y + 11, Theme.argb(rgb, 255));
                ctx.drawTextWithShadow(tr, m.name, sw - w - 5, y + 2, Theme.argb(rgb, 255));
                y += 11; i++;
            }
        }
    }

    // ------------------------------------------------------------ TargetHUD
    public static class TargetHUD extends Mod {
        final Setting color = add(Setting.mode("Color", Theme.MODES, 2));
        private float shown;
        private LivingEntity last;

        public TargetHUD() { super("TargetHUD", Category.HUD); }

        @Override
        public void onHud(DrawContext ctx, float td) {
            LivingEntity t = Target.get(6000);
            if (t == null) { last = null; return; }
            if (t != last) { shown = t.getHealth(); last = t; }
            TextRenderer tr = mc.textRenderer;
            int sw = mc.getWindow().getScaledWidth(), sh = mc.getWindow().getScaledHeight();
            int x = sw / 2 + 25, y = sh / 2 + 25, w = 130, h = 36;
            ctx.fill(x, y, x + w, y + h, 0xB0101010);
            ctx.drawTextWithShadow(tr, t.getName().getString(), x + 6, y + 5, 0xFFFFFFFF);
            float max = Math.max(1f, t.getMaxHealth());
            shown += (t.getHealth() - shown) * 0.15f;
            ctx.drawTextWithShadow(tr, f("%.1f HP", t.getHealth()), x + 6, y + 15, 0xFFAAAAAA);
            int bx = x + 6, bw = w - 12;
            ctx.fill(bx, y + 26, bx + bw, y + 31, 0xFF303030);
            int fw = (int) (bw * MathHelper.clamp(shown / max, 0f, 1f));
            for (int i = 0; i < fw; i += 2)
                ctx.fill(bx + i, y + 26, bx + Math.min(fw, i + 2), y + 31,
                        Theme.argb(Theme.rgb(color.i(), i / (double) bw), 255));
        }
    }

    // ------------------------------------------------------------ ArmorHUD
    public static class ArmorHUD extends Mod {
        public ArmorHUD() { super("ArmorHUD", Category.HUD); }

        @Override
        public void onHud(DrawContext ctx, float td) {
            int sw = mc.getWindow().getScaledWidth(), sh = mc.getWindow().getScaledHeight();
            int x0 = sw / 2 - 36, y = sh - 72;
            for (int i = 0; i < 4; i++) {
                ItemStack s = mc.player.getInventory().getArmorStack(3 - i);
                if (s.isEmpty()) continue;
                ctx.drawItem(s, x0 + i * 18, y);
                ctx.drawItemInSlot(mc.textRenderer, s, x0 + i * 18, y);
            }
        }
    }

    // ------------------------------------------------------------ Potions
    public static class Potions extends Mod {
        public Potions() { super("Potions", Category.HUD); }

        @Override
        public void onHud(DrawContext ctx, float td) {
            TextRenderer tr = mc.textRenderer;
            int sw = mc.getWindow().getScaledWidth(), sh = mc.getWindow().getScaledHeight();
            int y = sh - 16;
            for (StatusEffectInstance e : mc.player.getStatusEffects()) {
                int d = e.getDuration();
                String time = d < 0 ? "**" : f("%d:%02d", d / 1200, (d / 20) % 60);
                String s = e.getEffectType().getName().getString() + " " + (e.getAmplifier() + 1) + " " + time;
                ctx.drawTextWithShadow(tr, s, sw - tr.getWidth(s) - 4, y, 0xFFFFFFFF);
                y -= 11;
            }
        }
    }

    // ------------------------------------------------------------ Info lines (stacked, left side)
    public static class InfoModule extends Mod {
        private final Supplier<String> sup;

        public InfoModule(String name, Supplier<String> sup) { super(name, Category.HUD); this.sup = sup; }

        public String text() {
            try { return sup == null ? null : sup.get(); } catch (Exception e) { return null; }
        }
    }

    public static class CPS extends InfoModule {
        private final ArrayDeque<Long> clicks = new ArrayDeque<>();
        private boolean down;

        public CPS() { super("CPS", null); }

        @Override
        public void onTick() {
            boolean d = GLFW.glfwGetMouseButton(mc.getWindow().getHandle(), GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
            if (d && !down) clicks.add(System.currentTimeMillis());
            down = d;
        }

        @Override
        public String text() {
            long now = System.currentTimeMillis();
            while (!clicks.isEmpty() && now - clicks.peekFirst() > 1000) clicks.pollFirst();
            return String.valueOf(clicks.size());
        }
    }

    public static List<InfoModule> infoModules() {
        List<InfoModule> l = new ArrayList<>();
        l.add(new InfoModule("XYZ", () -> f("%.1f %.1f %.1f", mc().player.getX(), mc().player.getY(), mc().player.getZ())));
        l.add(new InfoModule("FPS", () -> String.valueOf(mc().getCurrentFps())));
        l.add(new InfoModule("Ping", () -> {
            var e = mc().getNetworkHandler() == null ? null
                    : mc().getNetworkHandler().getPlayerListEntry(mc().player.getUuid());
            return e == null ? "-" : e.getLatency() + " ms";
        }));
        l.add(new InfoModule("BPS", () -> f("%.2f", ModuleManager.bps)));
        l.add(new InfoModule("Clock", () -> LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm:ss"))));
        l.add(new InfoModule("Facing", () -> mc().player.getHorizontalFacing().asString()
                + f(" (%.0f)", MathHelper.wrapDegrees(mc().player.getYaw()))));
        l.add(new InfoModule("Server", () -> mc().getCurrentServerEntry() == null ? "Singleplayer"
                : mc().getCurrentServerEntry().address));
        l.add(new InfoModule("Totems", () -> {
            PlayerInventory inv = mc().player.getInventory();
            int n = 0;
            for (int i = 0; i < inv.size(); i++)
                if (inv.getStack(i).isOf(Items.TOTEM_OF_UNDYING)) n += inv.getStack(i).getCount();
            return String.valueOf(n);
        }));
        l.add(new CPS());
        l.add(new InfoModule("Players", () -> String.valueOf(mc().world.getPlayers().size())));
        l.add(new InfoModule("Memory", () -> {
            Runtime r = Runtime.getRuntime();
            return ((r.totalMemory() - r.freeMemory()) >> 20) + "/" + (r.maxMemory() >> 20) + " MB";
        }));
        l.add(new InfoModule("Durability", () -> {
            ItemStack s = mc().player.getMainHandStack();
            return s.isDamageable() ? (s.getMaxDamage() - s.getDamage()) + "/" + s.getMaxDamage() : null;
        }));
        l.add(new InfoModule("Combo", () -> String.valueOf(Target.combo)));
        l.add(new InfoModule("Health", () -> f("%.1f", mc().player.getHealth() + mc().player.getAbsorptionAmount())));
        return l;
    }

    private static net.minecraft.client.MinecraftClient mc() { return net.minecraft.client.MinecraftClient.getInstance(); }
}
