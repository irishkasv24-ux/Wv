package white.visual.gui;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;
import white.visual.core.Category;
import white.visual.core.Config;
import white.visual.core.Mod;
import white.visual.core.ModuleManager;
import white.visual.core.Setting;
import white.visual.core.Theme;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class ClickGui extends Screen {
    private static final class Row {
        int x, y, w, h;
        Mod m;
        Setting s;
        boolean in(int mx, int my) { return mx >= x && mx < x + w && my >= y && my < y + h; }
    }

    private static final int PW = 124, GAP = 8;
    private final List<Row> rows = new ArrayList<>();
    private Row dragging;
    private int mx, my;

    public ClickGui() { super(Text.literal("White Visual")); }

    @Override public boolean shouldPause() { return false; }
    @Override public void removed() { Config.save(); }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        mx = mouseX; my = mouseY;
        rows.clear();
        ctx.fill(0, 0, width, height, 0x55000000);

        Category[] cats = Category.values();
        int startX = (width - (cats.length * (PW + GAP) - GAP)) / 2;
        int acc = Theme.accent();

        for (int ci = 0; ci < cats.length; ci++) {
            Category c = cats[ci];
            int px = startX + ci * (PW + GAP), y = 24;
            ctx.fill(px, y, px + PW, y + 18, 0xFFFFFFFF);
            ctx.drawText(textRenderer, c.label, px + (PW - textRenderer.getWidth(c.label)) / 2, y + 5, 0xFF202020, false);
            for (int i = 0; i < PW; i += 2)
                ctx.fill(px + i, y + 18, px + i + 2, y + 20, Theme.argb(Theme.rgb(acc, i / (double) PW), 255));
            y += 20;

            List<Mod> list = new ArrayList<>();
            for (Mod m : ModuleManager.modules) if (m.category == c) list.add(m);
            list.sort(Comparator.comparing(m -> m.name));

            for (Mod m : list) {
                Row r = new Row(); r.x = px; r.y = y; r.w = PW; r.h = 16; r.m = m;
                rows.add(r);
                boolean hov = r.in(mx, my);
                int bg = m.enabled ? (hov ? 0xFF2C2C2C : 0xFF1E1E1E) : (hov ? 0xFFE6E6E6 : 0xFFF5F5F5);
                ctx.fill(px, y, px + PW, y + 16, bg);
                if (m.enabled) ctx.fill(px, y, px + 2, y + 16, Theme.argb(Theme.rgb(acc, y * 0.004), 255));
                ctx.drawText(textRenderer, m.name, px + 6, y + 4, m.enabled ? 0xFFFFFFFF : 0xFF202020, false);
                if (m.key >= 0) {
                    String k = "[" + InputUtil.fromKeyCode(m.key, 0).getLocalizedText().getString() + "]";
                    ctx.drawText(textRenderer, k, px + PW - textRenderer.getWidth(k) - 4, y + 4, 0xFF888888, false);
                } else if (!m.settings.isEmpty()) {
                    String k = m.expanded ? "-" : "+";
                    ctx.drawText(textRenderer, k, px + PW - 10, y + 4, 0xFF888888, false);
                }
                y += 16;

                if (m.expanded) {
                    for (Setting s : m.settings) {
                        Row sr = new Row(); sr.x = px; sr.y = y; sr.w = PW; sr.h = 14; sr.m = m; sr.s = s;
                        rows.add(sr);
                        ctx.fill(px, y, px + PW, y + 14, 0xFFE9E9E9);
                        if (s.type == Setting.Type.NUM) {
                            double f = (s.value - s.min) / (s.max - s.min);
                            ctx.fill(px, y, px + (int) (PW * f), y + 14, Theme.argb(Theme.mix(0xAFCBFF, 0xFFFFFF, 0.2), 255));
                        }
                        ctx.drawText(textRenderer, s.name, px + 8, y + 3, 0xFF202020, false);
                        String d = s.display();
                        ctx.drawText(textRenderer, d, px + PW - textRenderer.getWidth(d) - 6, y + 3, 0xFF555555, false);
                        y += 14;
                    }
                }
            }
        }
        String hint = "LMB: toggle  |  RMB: settings  |  press a key over a module to bind (Del = clear)  |  RShift: close";
        ctx.drawText(textRenderer, hint, (width - textRenderer.getWidth(hint)) / 2, height - 14, 0xFFFFFFFF, true);
    }

    private void setNum(Row r, double mouseX) {
        Setting s = r.s;
        double f = Math.max(0, Math.min(1, (mouseX - r.x) / r.w));
        double v = s.min + f * (s.max - s.min);
        v = Math.round(v / s.step) * s.step;
        s.value = Math.max(s.min, Math.min(s.max, v));
    }

    @Override
    public boolean mouseClicked(double x, double y, int btn) {
        for (Row r : rows) {
            if (!r.in((int) x, (int) y)) continue;
            if (r.s == null) {
                if (btn == 0) r.m.toggle();
                else if (btn == 1) r.m.expanded = !r.m.expanded;
            } else {
                Setting s = r.s;
                switch (s.type) {
                    case BOOL -> { if (btn == 0) s.value = s.b() ? 0 : 1; }
                    case MODE -> {
                        int n = s.modes.length;
                        s.value = btn == 1 ? (s.i() + n - 1) % n : (s.i() + 1) % n;
                    }
                    default -> { dragging = r; setNum(r, x); }
                }
            }
            return true;
        }
        return super.mouseClicked(x, y, btn);
    }

    @Override
    public boolean mouseDragged(double x, double y, int btn, double dx, double dy) {
        if (dragging != null) { setNum(dragging, x); return true; }
        return super.mouseDragged(x, y, btn, dx, dy);
    }

    @Override
    public boolean mouseReleased(double x, double y, int btn) {
        dragging = null;
        return super.mouseReleased(x, y, btn);
    }

    @Override
    public boolean keyPressed(int key, int scancode, int mods) {
        if (key == GLFW.GLFW_KEY_ESCAPE || key == GLFW.GLFW_KEY_RIGHT_SHIFT) { close(); return true; }
        for (Row r : rows) {
            if (r.s == null && r.in(mx, my)) {
                r.m.key = (key == GLFW.GLFW_KEY_BACKSPACE || key == GLFW.GLFW_KEY_DELETE) ? -1 : key;
                return true;
            }
        }
        return super.keyPressed(key, scancode, mods);
    }
}
