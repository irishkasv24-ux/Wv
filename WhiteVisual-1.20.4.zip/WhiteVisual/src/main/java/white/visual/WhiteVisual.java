package white.visual;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.ActionResult;
import net.minecraft.util.math.Vec3d;
import white.visual.core.Config;
import white.visual.core.ModuleManager;
import white.visual.core.Target;

public class WhiteVisual implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        ModuleManager.init();

        ClientTickEvents.END_CLIENT_TICK.register(client -> ModuleManager.tick());

        WorldRenderEvents.LAST.register(ctx -> {
            MatrixStack ms = ctx.matrixStack();
            if (ms == null) return;
            Vec3d cam = ctx.camera().getPos();
            ms.push();
            ms.translate(-cam.x, -cam.y, -cam.z);
            ModuleManager.render3d(ms, ctx.tickDelta());
            ms.pop();
        });

        HudRenderCallback.EVENT.register(ModuleManager::renderHud);

        AttackEntityCallback.EVENT.register((player, world, hand, entity, hit) -> {
            if (world.isClient && player == MinecraftClient.getInstance().player) {
                Target.set(entity);
                ModuleManager.onAttack(entity);
            }
            return ActionResult.PASS;
        });

        ClientLifecycleEvents.CLIENT_STOPPING.register(c -> Config.save());
    }
}
