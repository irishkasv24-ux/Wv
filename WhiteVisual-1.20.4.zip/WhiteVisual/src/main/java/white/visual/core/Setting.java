package white.visual.core;

import java.util.Locale;

public class Setting {
    public enum Type { BOOL, NUM, MODE }

    public final String name;
    public final Type type;
    public double value, min, max, step = 1;
    public String[] modes;

    private Setting(String name, Type type) { this.name = name; this.type = type; }

    public static Setting bool(String n, boolean v) {
        Setting s = new Setting(n, Type.BOOL);
        s.value = v ? 1 : 0;
        return s;
    }

    public static Setting num(String n, double v, double min, double max, double step) {
        Setting s = new Setting(n, Type.NUM);
        s.value = v; s.min = min; s.max = max; s.step = step;
        return s;
    }

    public static Setting mode(String n, String[] modes, int idx) {
        Setting s = new Setting(n, Type.MODE);
        s.modes = modes; s.value = idx; s.min = 0; s.max = modes.length - 1;
        return s;
    }

    public boolean b() { return value > 0.5; }
    public double d() { return value; }
    public int i() { return (int) Math.round(value); }

    public String display() {
        switch (type) {
            case BOOL: return b() ? "On" : "Off";
            case MODE: return modes[Math.max(0, Math.min(modes.length - 1, i()))];
            default: return step < 1 ? String.format(Locale.ROOT, "%.2f", value) : String.valueOf(i());
        }
    }
}
