package white.visual.core;

import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

public final class Config {
    private Config() {}

    private static Path path() { return FabricLoader.getInstance().getConfigDir().resolve("whitevisual.properties"); }

    public static void save() {
        Properties p = new Properties();
        for (Mod m : ModuleManager.modules) {
            p.setProperty(m.name + ".enabled", String.valueOf(m.enabled));
            p.setProperty(m.name + ".key", String.valueOf(m.key));
            for (Setting s : m.settings) p.setProperty(m.name + "." + s.name, String.valueOf(s.value));
        }
        try (OutputStream o = Files.newOutputStream(path())) {
            p.store(o, "White Visual");
        } catch (IOException ignored) {}
    }

    public static void load() {
        Properties p = new Properties();
        try (InputStream in = Files.newInputStream(path())) {
            p.load(in);
        } catch (IOException e) {
            return;
        }
        for (Mod m : ModuleManager.modules) {
            m.enabled = Boolean.parseBoolean(p.getProperty(m.name + ".enabled", String.valueOf(m.enabled)));
            try { m.key = Integer.parseInt(p.getProperty(m.name + ".key", "-1")); } catch (NumberFormatException ignored) {}
            for (Setting s : m.settings) {
                try {
                    double v = Double.parseDouble(p.getProperty(m.name + "." + s.name, String.valueOf(s.value)));
                    s.value = Math.max(s.type == Setting.Type.BOOL ? 0 : s.min, Math.min(s.type == Setting.Type.BOOL ? 1 : s.max, v));
                } catch (NumberFormatException ignored) {}
            }
        }
    }
}
