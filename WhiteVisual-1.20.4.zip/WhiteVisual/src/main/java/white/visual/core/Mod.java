package white.visual.core;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;

import java.util.ArrayList;
import java.util.List;

public class Mod {
    protected static final MinecraftClient mc = MinecraftClient.getInstance();

    public final String name;
    public final Category category;
    public boolean enabled;
    public boolean expanded;
    public boolean keyDown;
    public int key = -1;
    public final List<Setting> settings = new ArrayList<>();

    public Mod(String name, Category category) { this.name = name; this.category = category; }

    protected <T extends Setting> T add(T s) { settings.add(s); return s; }
    public Mod defOn() { enabled = true; return this; }

    public void toggle() {
        enabled = !enabled;
        if (enabled) onEnable(); else onDisable();
    }

    public void onEnable() {}
    public void onDisable() {}
    public void onTick() {}
    public void onRender3d(MatrixStack ms, float td) {}
    public void onHud(DrawContext ctx, float td) {}
    public void onAttack(Entity e) {}
}
