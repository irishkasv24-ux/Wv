package white.visual.core;

import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;

public final class Target {
    private Target() {}

    public static LivingEntity entity;
    public static long time;
    public static int combo;

    public static void set(Entity e) {
        if (e instanceof LivingEntity le) {
            entity = le;
            time = System.currentTimeMillis();
            combo++;
        }
    }

    public static LivingEntity get(long maxAgeMs) {
        if (entity == null) return null;
        if (entity.isRemoved() || !entity.isAlive()) return null;
        if (System.currentTimeMillis() - time > maxAgeMs) return null;
        return entity;
    }
}
