package white.visual.core;

import java.awt.Color;

public final class Theme {
    private Theme() {}

    public static final String[] MODES = {"White", "Rainbow", "Blue", "Pink", "Red"};
    public static Setting accent;

    public static int accent() { return accent == null ? 2 : accent.i(); }

    public static int rgb(int mode, double off) {
        double t = System.currentTimeMillis() / 1000.0;
        double s = (Math.sin(t * 2.0 + off * Math.PI * 2) + 1) / 2;
        switch (mode) {
            case 1: return Color.HSBtoRGB((float) (((t * 0.2 + off) % 1 + 1) % 1), 0.55f, 1f) & 0xFFFFFF;
            case 2: return mix(0x7FB2FF, 0xFFFFFF, s);
            case 3: return mix(0xFF8AD8, 0xFFFFFF, s);
            case 4: return mix(0xFF3030, 0xFFB0B0, s);
            default: return 0xFFFFFF;
        }
    }

    public static int mix(int a, int b, double t) {
        int r = (int) (((a >> 16) & 255) * (1 - t) + ((b >> 16) & 255) * t);
        int g = (int) (((a >> 8) & 255) * (1 - t) + ((b >> 8) & 255) * t);
        int bl = (int) ((a & 255) * (1 - t) + (b & 255) * t);
        return (r << 16) | (g << 8) | bl;
    }

    public static int argb(int rgb, int a) { return (a << 24) | (rgb & 0xFFFFFF); }
}
