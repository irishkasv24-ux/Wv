package white.visual.core;

public enum Category {
    RENDER("Render"), HUD("HUD"), MISC("Misc");
    public final String label;
    Category(String label) { this.label = label; }
}
