package white.visual.core;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormat;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;

public final class RenderUtil {
    private RenderUtil() {}

    public static void begin(boolean depth) {
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableCull();
        if (depth) RenderSystem.enableDepthTest(); else RenderSystem.disableDepthTest();
        RenderSystem.setShader(GameRenderer::getPositionColorProgram);
    }

    public static void end() {
        RenderSystem.lineWidth(1f);
        RenderSystem.enableCull();
        RenderSystem.enableDepthTest();
        RenderSystem.disableBlend();
    }

    public static Vec3d pos(Entity e, float td) {
        return new Vec3d(MathHelper.lerp(td, e.prevX, e.getX()),
                MathHelper.lerp(td, e.prevY, e.getY()),
                MathHelper.lerp(td, e.prevZ, e.getZ()));
    }

    public static Box entityBox(Entity e, float td) {
        Vec3d p = pos(e, td);
        return e.getBoundingBox().offset(p.x - e.getX(), p.y - e.getY(), p.z - e.getZ());
    }

    private static void v(BufferBuilder b, Matrix4f m, double x, double y, double z, int rgb, int a) {
        b.vertex(m, (float) x, (float) y, (float) z)
                .color((rgb >> 16) & 255, (rgb >> 8) & 255, rgb & 255, MathHelper.clamp(a, 0, 255)).next();
    }

    /** Band between two circles: (r0,y0,a0) bottom edge and (r1,y1,a1) top edge. Used for rings, cones, glow bands. */
    public static void ribbon(MatrixStack ms, double cx, double cz,
                              double r0, double y0, int a0, double r1, double y1, int a1,
                              int mode, double off, int segs) {
        Matrix4f m = ms.peek().getPositionMatrix();
        BufferBuilder b = Tessellator.getInstance().getBuffer();
        b.begin(VertexFormat.DrawMode.TRIANGLE_STRIP, VertexFormats.POSITION_COLOR);
        for (int i = 0; i <= segs; i++) {
            double f = (double) i / segs, ang = f * Math.PI * 2;
            double cs = Math.cos(ang), sn = Math.sin(ang);
            int rgb = Theme.rgb(mode, f + off);
            v(b, m, cx + cs * r0, y0, cz + sn * r0, rgb, a0);
            v(b, m, cx + cs * r1, y1, cz + sn * r1, rgb, a1);
        }
        Tessellator.getInstance().draw();
    }

    public static void ringLine(MatrixStack ms, double cx, double y, double cz, double r,
                                int mode, int a, int segs, float width) {
        Matrix4f m = ms.peek().getPositionMatrix();
        RenderSystem.lineWidth(width);
        BufferBuilder b = Tessellator.getInstance().getBuffer();
        b.begin(VertexFormat.DrawMode.DEBUG_LINES, VertexFormats.POSITION_COLOR);
        for (int i = 0; i < segs; i++) {
            double f0 = (double) i / segs, f1 = (double) (i + 1) / segs;
            double a0 = f0 * Math.PI * 2, a1 = f1 * Math.PI * 2;
            v(b, m, cx + Math.cos(a0) * r, y, cz + Math.sin(a0) * r, Theme.rgb(mode, f0), a);
            v(b, m, cx + Math.cos(a1) * r, y, cz + Math.sin(a1) * r, Theme.rgb(mode, f1), a);
        }
        Tessellator.getInstance().draw();
    }

    public static void line(MatrixStack ms, Vec3d p1, Vec3d p2, int rgb1, int rgb2, int a, float width) {
        Matrix4f m = ms.peek().getPositionMatrix();
        RenderSystem.lineWidth(width);
        BufferBuilder b = Tessellator.getInstance().getBuffer();
        b.begin(VertexFormat.DrawMode.DEBUG_LINES, VertexFormats.POSITION_COLOR);
        v(b, m, p1.x, p1.y, p1.z, rgb1, a);
        v(b, m, p2.x, p2.y, p2.z, rgb2, a);
        Tessellator.getInstance().draw();
    }

    public static void box(MatrixStack ms, Box bx, int rgb, int fillA, int lineA) {
        Matrix4f m = ms.peek().getPositionMatrix();
        double x1 = bx.minX, y1 = bx.minY, z1 = bx.minZ, x2 = bx.maxX, y2 = bx.maxY, z2 = bx.maxZ;
        if (fillA > 0) {
            BufferBuilder b = Tessellator.getInstance().getBuffer();
            b.begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR);
            double[][] f = {
                    {x1,y1,z1, x2,y1,z1, x2,y1,z2, x1,y1,z2},
                    {x1,y2,z1, x1,y2,z2, x2,y2,z2, x2,y2,z1},
                    {x1,y1,z1, x1,y2,z1, x2,y2,z1, x2,y1,z1},
                    {x1,y1,z2, x2,y1,z2, x2,y2,z2, x1,y2,z2},
                    {x1,y1,z1, x1,y1,z2, x1,y2,z2, x1,y2,z1},
                    {x2,y1,z1, x2,y2,z1, x2,y2,z2, x2,y1,z2}};
            for (double[] q : f)
                for (int i = 0; i < 4; i++) v(b, m, q[i * 3], q[i * 3 + 1], q[i * 3 + 2], rgb, fillA);
            Tessellator.getInstance().draw();
        }
        if (lineA > 0) {
            RenderSystem.lineWidth(1.6f);
            BufferBuilder b = Tessellator.getInstance().getBuffer();
            b.begin(VertexFormat.DrawMode.DEBUG_LINES, VertexFormats.POSITION_COLOR);
            double[][] e = {
                    {x1,y1,z1, x2,y1,z1}, {x2,y1,z1, x2,y1,z2}, {x2,y1,z2, x1,y1,z2}, {x1,y1,z2, x1,y1,z1},
                    {x1,y2,z1, x2,y2,z1}, {x2,y2,z1, x2,y2,z2}, {x2,y2,z2, x1,y2,z2}, {x1,y2,z2, x1,y2,z1},
                    {x1,y1,z1, x1,y2,z1}, {x2,y1,z1, x2,y2,z1}, {x2,y1,z2, x2,y2,z2}, {x1,y1,z2, x1,y2,z2}};
            for (double[] l : e) {
                v(b, m, l[0], l[1], l[2], rgb, lineA);
                v(b, m, l[3], l[4], l[5], rgb, lineA);
            }
            Tessellator.getInstance().draw();
        }
    }
}
