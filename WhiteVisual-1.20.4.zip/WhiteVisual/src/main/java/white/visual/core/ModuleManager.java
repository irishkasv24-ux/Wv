package white.visual.core;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.util.InputUtil;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import org.lwjgl.glfw.GLFW;
import white.visual.gui.ClickGui;
import white.visual.modules.HudMods;
import white.visual.modules.HudMods.InfoModule;
import white.visual.modules.MiscMods;
import white.visual.modules.RenderMods;

import java.util.ArrayList;
import java.util.List;

public final class ModuleManager {
    private ModuleManager() {}

    public static final List<Mod> modules = new ArrayList<>();
    public static double bps;
    private static double lx, lz;
    private static boolean rsDown;
    private static final MinecraftClient mc = MinecraftClient.getInstance();

    private static void reg(Mod m) { modules.add(m); }

    public static void init() {
        // Render (12)
        reg(new RenderMods.TargetESP().defOn());
        reg(new RenderMods.ChinaHat().defOn());
        reg(new RenderMods.PlayerESP());
        reg(new RenderMods.MobESP());
        reg(new RenderMods.ItemESP());
        reg(new RenderMods.Tracers());
        reg(new RenderMods.Trails());
        reg(new RenderMods.Hitboxes());
        reg(new RenderMods.Halo());
        reg(new RenderMods.JumpCircles());
        reg(new RenderMods.FeetCircle());
        reg(new RenderMods.Glow());
        // HUD (5 + 14 info lines)
        reg(new HudMods.Watermark().defOn());
        reg(new HudMods.ArrayListHud().defOn());
        reg(new HudMods.TargetHUD().defOn());
        reg(new HudMods.ArmorHUD());
        reg(new HudMods.Potions());
        for (InfoModule im : HudMods.infoModules()) reg(im);
        // Misc (5)
        reg(new MiscMods.ThemeMod());
        reg(new MiscMods.FullBright());
        reg(new MiscMods.Zoom());
        reg(new MiscMods.FovChanger());
        reg(new MiscMods.HitParticles());
        Config.load();
    }

    public static void tick() {
        if (mc.player == null || mc.world == null) return;

        double dx = mc.player.getX() - lx, dz = mc.player.getZ() - lz;
        bps = bps * 0.7 + Math.hypot(dx, dz) * 20 * 0.3;
        lx = mc.player.getX(); lz = mc.player.getZ();
        if (mc.player.hurtTime > 0) Target.combo = 0;

        if (mc.currentScreen == null) {
            long h = mc.getWindow().getHandle();
            boolean rs = InputUtil.isKeyPressed(h, GLFW.GLFW_KEY_RIGHT_SHIFT);
            if (rs && !rsDown) mc.setScreen(new ClickGui());
            rsDown = rs;
            for (Mod m : modules) {
                if (m.key < 0) continue;
                boolean d = InputUtil.isKeyPressed(h, m.key);
                if (d && !m.keyDown) m.toggle();
                m.keyDown = d;
            }
        }
        for (Mod m : modules) if (m.enabled) m.onTick();
    }

    public static void render3d(MatrixStack ms, float td) {
        if (mc.player == null || mc.world == null) return;
        for (Mod m : modules) if (m.enabled) m.onRender3d(ms, td);
    }

    public static void renderHud(DrawContext ctx, float td) {
        if (mc.player == null || mc.world == null || mc.options.hudHidden) return;
        for (Mod m : modules) if (m.enabled && !(m instanceof InfoModule)) m.onHud(ctx, td);

        TextRenderer tr = mc.textRenderer;
        int acc = Theme.accent();
        int y = 22;
        for (Mod m : modules) {
            if (!m.enabled || !(m instanceof InfoModule im)) continue;
            String v = im.text();
            if (v == null) continue;
            String label = im.name + " ";
            int w = tr.getWidth(label + v) + 8;
            int col = Theme.argb(Theme.rgb(acc, y * 0.01), 255);
            ctx.fill(4, y, 4 + w, y + 12, 0x90101010);
            ctx.fill(4, y, 6, y + 12, col);
            ctx.drawTextWithShadow(tr, label, 9, y + 2, col);
            ctx.drawTextWithShadow(tr, v, 9 + tr.getWidth(label), y + 2, 0xFFFFFFFF);
            y += 13;
        }
    }

    public static void onAttack(Entity e) {
        for (Mod m : modules) if (m.enabled) m.onAttack(e);
    }
}
